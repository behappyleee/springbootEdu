package com.springboot.serverbox;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServerboxApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServerboxApplication.class, args);
	}

}
